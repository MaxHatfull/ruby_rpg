var searchData=
[
  ['0_0',['0',['../news.html#features_30',1,'New features in version 3.0'],['../news.html#news_30',1,'Release notes for 3.0']]],
  ['0_20or_20later_20is_20required_1',['CMake 3.0 or later is required',['../news.html#cmake_version_33',1,'']]]
];
