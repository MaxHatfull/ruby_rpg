var searchData=
[
  ['notes_0',['Release notes',['../news.html',1,'']]],
  ['notitle_1',['notitle',['../index.html',1,'']]]
];
