var searchData=
[
  ['1_0',['1',['../news.html#features_31',1,'New features in version 3.1'],['../news.html#news_31',1,'Release notes for 3.1']]]
];
