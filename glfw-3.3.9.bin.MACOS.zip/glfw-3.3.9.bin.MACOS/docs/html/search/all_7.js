var searchData=
[
  ['damage_20and_20refresh_0',['Window damage and refresh',['../window_guide.html#window_refresh',1,'']]],
  ['deadzone_20removed_1',['Windows XInput deadzone removed',['../news.html#xinput_deadzone_33',1,'']]],
  ['decorations_2',['Wayland libdecor decorations',['../news.html#wayland_libdecor_33',1,'']]],
  ['default_20values_3',['default values',['../intro_guide.html#init_hints_values',1,'Supported and default values'],['../window_guide.html#window_hints_values',1,'Supported and default values']]],
  ['dependencies_4',['Installing dependencies',['../compile_guide.html#compile_deps',1,'']]],
  ['dependencies_20for_20wayland_20on_20unix_20like_20systems_5',['Dependencies for Wayland on Unix-like systems',['../compile_guide.html#compile_deps_wayland',1,'']]],
  ['dependencies_20for_20x11_20on_20unix_20like_20systems_6',['Dependencies for X11 on Unix-like systems',['../compile_guide.html#compile_deps_x11',1,'']]],
  ['dependency_7',['LunarG Vulkan SDK dependency',['../news.html#vulkan_sdk_33',1,'']]],
  ['deprecated_20list_8',['Deprecated List',['../deprecated.html',1,'']]],
  ['deprecations_20in_20version_203_203_9',['Deprecations in version 3.3',['../news.html#deprecations_33',1,'']]],
  ['destruction_10',['destruction',['../input_guide.html#cursor_destruction',1,'Cursor destruction'],['../window_guide.html#window_destruction',1,'Window destruction']]],
  ['direct_20access_20for_20window_20attributes_20and_20cursor_20position_11',['Direct access for window attributes and cursor position',['../news.html#news_31_direct',1,'']]],
  ['documentation_12',['Doxygen documentation',['../news.html#news_30_doxygen',1,'']]],
  ['doxygen_20documentation_13',['Doxygen documentation',['../news.html#news_30_doxygen',1,'']]],
  ['dpi_20aware_20rendering_14',['Content scale queries for DPI-aware rendering',['../news.html#content_scale_33',1,'']]],
  ['dpi_20support_15',['High-DPI support',['../news.html#news_30_hidpi',1,'']]],
  ['drop_20event_16',['Path drop event',['../news.html#news_31_drop',1,'']]],
  ['drop_20input_17',['Path drop input',['../input_guide.html#path_drop',1,'']]],
  ['dwm_20transparency_18',['Framebuffer transparency requires DWM transparency',['../news.html#caveat_fbtransparency_33',1,'']]],
  ['dynamically_19',['X11 extension libraries are loaded dynamically',['../news.html#x11_linking_33',1,'']]]
];
