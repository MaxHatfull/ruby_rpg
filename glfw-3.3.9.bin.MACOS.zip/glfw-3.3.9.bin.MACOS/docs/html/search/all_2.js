var searchData=
[
  ['2_0',['2',['../news.html#features_32',1,'New features in version 3.2'],['../news.html#news_32',1,'Release notes for 3.2']]],
  ['2_20to_203_1',['Moving from GLFW 2 to 3',['../moving_guide.html',1,'']]],
  ['256_20may_20be_20rejected_2',['Gamma ramp size of 256 may be rejected',['../news.html#gamma_ramp_size_33',1,'']]]
];
