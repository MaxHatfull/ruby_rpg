var searchData=
[
  ['queries_20for_20dpi_20aware_20rendering_0',['Content scale queries for DPI-aware rendering',['../news.html#content_scale_33',1,'']]],
  ['query_1',['query',['../news.html#geterror_33',1,'Error query'],['../news.html#news_31_framesize',1,'Window frame size query'],['../news.html#news_30_wndpos',1,'Window position query']]],
  ['query_20for_20the_20monitor_20work_20area_2',['Query for the monitor work area',['../news.html#workarea_33',1,'']]],
  ['query_20for_20the_20scancode_20of_20a_20key_3',['Query for the scancode of a key',['../news.html#key_scancode_33',1,'']]],
  ['querying_20for_20vulkan_20presentation_20support_4',['Querying for Vulkan presentation support',['../vulkan_guide.html#vulkan_present',1,'']]],
  ['querying_20for_20vulkan_20support_5',['Querying for Vulkan support',['../vulkan_guide.html#vulkan_support',1,'']]],
  ['querying_20required_20vulkan_20extensions_6',['Querying required Vulkan extensions',['../vulkan_guide.html#vulkan_ext',1,'']]],
  ['querying_20vulkan_20function_20pointers_7',['Querying Vulkan function pointers',['../vulkan_guide.html#vulkan_proc',1,'']]],
  ['quick_2edox_8',['quick.dox',['../quick_8dox.html',1,'']]]
];
