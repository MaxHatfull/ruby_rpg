var searchData=
[
  ['x11_20clipboard_20transfer_20limits_0',['X11 clipboard transfer limits',['../news.html#x11_clipboard_33',1,'']]],
  ['x11_20extension_20libraries_20are_20loaded_20dynamically_1',['X11 extension libraries are loaded dynamically',['../news.html#x11_linking_33',1,'']]],
  ['x11_20extensions_20protocols_20and_20ipc_20standards_2',['X11 extensions, protocols and IPC standards',['../compat_guide.html#compat_x11',1,'']]],
  ['x11_20no_20longer_20roundtrip_20to_20server_3',['Empty events on X11 no longer roundtrip to server',['../news.html#emptyevents_33',1,'']]],
  ['x11_20on_20unix_20like_20systems_4',['Dependencies for X11 on Unix-like systems',['../compile_guide.html#compile_deps_x11',1,'']]],
  ['x11_20specific_20window_20hints_5',['X11 specific window hints',['../window_guide.html#window_hints_x11',1,'']]],
  ['xcode_20on_20macos_6',['With Xcode on macOS',['../build_guide.html#build_link_xcode',1,'']]],
  ['xinput_20deadzone_20removed_7',['Windows XInput deadzone removed',['../news.html#xinput_deadzone_33',1,'']]],
  ['xp_8',['Support for versions of Windows older than XP',['../moving_guide.html#moving_windows',1,'']]]
];
